package it.polimi.ingsw.am55.network.rmi.server;

import it.polimi.ingsw.am55.MesosModel.Game.Game;
import it.polimi.ingsw.am55.MesosModel.Game.GameModelInterface;
import it.polimi.ingsw.am55.message.MessageToClient;
import it.polimi.ingsw.am55.network.rmi.client.VirtualViewRmi;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import it.polimi.ingsw.am55.controller.GameController;

public class RmiServer extends UnicastRemoteObject implements VirtualServerRmi {

    private final GameController controller;          // CONTROLLER SERVER-SIDE
    private final List<VirtualViewRmi> clients;      // CALLBACK REMOTE DEI CLIENT REGISTRATI

    public RmiServer(GameController controller) throws RemoteException {
        super(); // ESPORTA L'OGGETTO REMOTO SERVER-SIDE
        this.controller = controller;
        this.clients = new ArrayList<>();
    }

    public static void main(String[] args) throws Exception {
        final String serverName = "GameServer";
        final int port = 1234;
        //inizialmente sono nulli all'avvio del server, perche devo aspettare che un client faccia creategame
        GameController controller = new GameController();

        RmiServer server = new RmiServer(controller);

        // CREO IL REGISTRY RMI SULLA PORTA SCELTA
        Registry registry = LocateRegistry.createRegistry(port);

        // REGISTRO L'OGGETTO REMOTO SERVER NEL REGISTRY
        registry.rebind(serverName, server);

        System.out.println("RmiServer avviato correttamente.");
    }

    /**
     * Metodo usato dal client per registrarsi presso il server,
     * così il server può effettuare callback su di lui tramite onMessage(...).
     */
    @Override
    public void connect(VirtualViewRmi client) throws RemoteException {
        synchronized (clients) {
            clients.add(client);
        }
    }

    /**
     * Metodo remoto chiamato dal client quando vuole eseguire l'azione placeTotem.
     * <p>
     * Il server:
     * - riceve la richiesta remota
     * - delega la logica applicativa al GameController
     * - ottiene un MessageToClient generico
     * - lo inoltra ai client registrati tramite callback onMessage(...)
     */
    @Override
    public void placeTotem(String playerId, int index) throws RemoteException {
        MessageToClient message = controller.placeTotem(playerId, index);

        synchronized (clients) {
            for (VirtualViewRmi client : clients) {
                try {
                    client.onMessage(message);
                } catch (RemoteException e) {
                    System.out.println("Client disconnesso durante l'invio del messaggio.");
                }
            }
        }
    }
}