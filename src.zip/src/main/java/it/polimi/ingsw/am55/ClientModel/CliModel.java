package it.polimi.ingsw.am55.ClientModel;

public class CliModel {
    String board;

}
