package it.polimi.ingsw.am55.message;

public interface MessageToClient {
}
