package it.polimi.ingsw.am55.virtualview;

/**
 * Interfaccia che definisce i metodi che il client
 * può invocare sul server.
 *
 * Rappresenta il contratto logico client -> server,
 * indipendente dalla tecnologia di comunicazione usata.
 */
public interface VirtualServer {

    /**
     * Azione richiesta dal client: placeTotem.
     */
    void placeTotem(String playerId, int index) throws Exception;

    /*
    void pickCard(String playerId, int cardId) throws Exception;

    void endTurn(String playerId) throws Exception;
    */
}