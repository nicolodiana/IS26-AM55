package it.polimi.ingsw.am55.controller;
import it.polimi.ingsw.am55.MesosModel.Game.Game;
import it.polimi.ingsw.am55.MesosModel.Game.GameModelInterface;
import it.polimi.ingsw.am55.message.BoardUpdatedMessage;
import it.polimi.ingsw.am55.message.MessageToClient;

/**
 * Controller server-side.
 *
 * Si occupa di:
 * - ricevere la richiesta logica dal layer di rete
 * - chiamare il model di gioco
 * - costruire il MessageToClient da restituire a RmiServer
 *
 * Non si occupa di inviare direttamente il messaggio ai client:
 * quello lo fa RmiServer.
 */
public class GameController {
//inizialmente il rif al gameModel è nullo, solo con la prima createGame dovrebbe crearsi
    private final GameModelInterface gameModel=null;


    public MessageToClient createGame(String playerId, int numplayers) {
        if (gameModel != null) {
            return new ErrorMessage("La partita esiste già.");
        }

        gameModel = new Game(numplayers);
        gameModel.addPlayer(playerId);

        return new InfoMessage("Partita creata con successo.");
    }
    public MessageToClient placeTotem(String playerId, int index) {
        try {
            gameModel.placeTotem(playerId, index);
            return new BoardUpdatedMessage("board");
        } catch (IllegalArgumentException e) {
            return new ErrorMessage(e.getMessage()); //da rivedere il catch
        }
    }
}

    /*
    public MessageToClient pickCard(String playerId, int cardId) {
        try {
            game.pickCard(playerId, cardId);

            BoardDto boardDto = BoardDto.from(game.getBoard());
            return new BoardUpdatedMessage(boardDto);

        } catch (IllegalArgumentException e) {
            return new ErrorMessage(e.getMessage());
        }
    }

    public MessageToClient endTurn(String playerId) {
        try {
            game.endTurn(playerId);

            BoardDto boardDto = BoardDto.from(game.getBoard());
            return new BoardUpdatedMessage(boardDto);

        } catch (IllegalArgumentException e) {
            return new ErrorMessage(e.getMessage());
        }
    }
    */
}