package it.polimi.ingsw.am55.controller;

import it.polimi.ingsw.am55.network.rmi.client.RmiClient;


import java.rmi.RemoteException;

public class ClientController implements UserActionHandler {

    private final RmiClient rmiClient;

    public ClientController(RmiClient rmiClient) {
        this.rmiClient = rmiClient;
    }

    @Override
    public void onPlaceTotemSelected(int index) {
        try {
            rmiClient.placeTotem(index);
        } catch (RemoteException e) {
            System.err.println("Errore durante la chiamata RMI di placeTotem: " + e.getMessage());
        }
    }
}