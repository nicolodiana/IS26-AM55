package it.polimi.ingsw.am55.message;

public class BoardUpdatedMessage {
    String board;

    public BoardUpdatedMessage(String board) {}
}
