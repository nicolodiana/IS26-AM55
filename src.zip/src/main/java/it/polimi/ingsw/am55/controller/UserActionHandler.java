package it.polimi.ingsw.am55.controller;

public interface UserActionHandler {
    void onPlaceTotemSelected(int index);
}