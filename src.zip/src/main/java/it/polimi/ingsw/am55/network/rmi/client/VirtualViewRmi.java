package it.polimi.ingsw.am55.network.rmi.client;

import it.polimi.ingsw.am55.message.MessageToClient;
import it.polimi.ingsw.am55.virtualview.VirtualView;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Questa interfaccia specializza VirtualView per la tecnologia RMI.
 *
 * Sono le callback che il client espone al server tramite RMI,
 * attraverso cui il server può notificare il client dopo una modifica sul model server.
 */
public interface VirtualViewRmi extends Remote, VirtualView {

    @Override
    void onMessage(MessageToClient message) throws RemoteException;
}