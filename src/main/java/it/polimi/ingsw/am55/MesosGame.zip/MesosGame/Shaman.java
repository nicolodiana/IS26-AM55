package it.polimi.ingsw.mesos.MesosGame;

public class Shaman extends Card {
    private int numStars;

    public Shaman(int numStars) {
        this.numStars = numStars;
    }

    @Override
    public void addCard(Player player) {
        player.addTribeCard(this);
    }

    public int getNumStars() {
        return this.numStars;
    }
}
