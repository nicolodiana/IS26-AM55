package it.polimi.ingsw.mesos.MesosGame;

public class BuildingCard extends Card {
    private int foodCost;
    private int numOfPP;
    BuildingType type;
    Class<? extends Card> targetType; // serve per prendere solo il tipo di classe senza doverla istanziare

    public BuildingCard(int foodCost, int numOfPP, BuildingType type) {
        this.foodCost = foodCost;
        this.numOfPP = numOfPP;
        this.type = type;
    }

    public void addCard(Player player) {
        player.payFood(foodCost);
        player.addTribeCard(this);
    }

    public Class<? extends Card> getTargetType() {
        return targetType;
    }

    public int getNumOfPP() {
        return numOfPP;
    }
    public int getFoodCost() {
        return foodCost;
    }

    public void removeBuildingCardFromRow(Row row){
        row.getBuildingCardsList().removeBuildingCard(this);
    }



}
