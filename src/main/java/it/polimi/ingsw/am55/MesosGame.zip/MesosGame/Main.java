package it.polimi.ingsw.mesos.MesosGame;

public class Main {
    public static void main(String[] args) {


    }
}
