package it.polimi.ingsw.mesos.MesosGame;

public class Inventor extends Card {
    private String iconInvention;

    public void addCard(Player player) {
        player.addTribeCard(this);
    }

}
