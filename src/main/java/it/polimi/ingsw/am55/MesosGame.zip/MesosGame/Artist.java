package it.polimi.ingsw.mesos.MesosGame;

public class Artist extends Card {
    @Override
    public void addCard(Player player) {
        player.addTribeCard(this);
    }
}
