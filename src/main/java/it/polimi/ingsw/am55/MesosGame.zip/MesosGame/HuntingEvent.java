import java.util.List;
package it.polimi.ingsw.mesos.MesosGame;
public class HuntingEvent extends Event {
    private int numPP;

    public HuntingEvent(int numPP) {
        this.numPP = numPP;
    }

    public void activateEvent(List<Player> players) {

        for (Player p : players) {
            int multiplier = p.getHuntersList().size();
            int doubleGain = p.hasBuilding(BuildingType.BUILDING8) ? 2 : 1;

            p.addPP(multiplier * numPP * doubleGain);
            p.addFood(multiplier * doubleGain);
        }
    }
}