import java.util.List;
package it.polimi.ingsw.mesos.MesosGame;
public class ShamanRitual extends Event {
    private int maxStars;
    private int minStars;
    private int maxPP;
    private int minPP;

    public int searchMaxStars(List<Player> list) {
        int max = 0;

        for (Player p : list) {
            int tmp = p.resolveEvent(this);
            if (max < tmp) { max = tmp; }
        }
        return max;
    }

    public int searchMinStars(List<Player> list) {
        int min = 0;

        for (Player p : list) {
            int tmp = p.resolveEvent(this);
            if (min > tmp) { min = tmp; }
        }
        return min;
    }


    @Override
    public void activateEvent(List<Player> players) {// manca caso in cui ce ne sia piu di uno uguali
        int doublePP = 0;
        for (Player p : players) {
            if (p.resolveEvent(this) == searchMaxStars(players)) {
                doublePP = p.hasBuilding(BuildingType.BUILDING7) ? 2 : 1;
                p.addPP(maxPP * doublePP);
            }
            else if (p.hasBuilding(BuildingType.BUILDING3)) { return; }
            else if (p.resolveEvent(this) == searchMinStars(players)) { p.payPP(minPP); }
        }
    }
}