import java.util.List;
package it.polimi.ingsw.mesos.MesosGame;
public class Event {
    public void activateEvent(Player player) {}
    public void activateEvent(List<Player> players) {}
}
