package it.polimi.ingsw.mesos.MesosGame;

public class Hunter extends Card {
    private Boolean icon;

    public void addCard(Player player) {
        player.addTribeCard(this);
    }
}
