package it.polimi.ingsw.mesos.MesosGame;

public class Builder extends Card {
    int numPP;

    public int getNumPP() {
        return numPP;
    }

    public void addCard(Player player) {
        player.addTribeCard(this);
    }
}
