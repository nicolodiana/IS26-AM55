import java.util.List;
package it.polimi.ingsw.mesos.MesosGame;
public class EndRoundResolver{

    ////EDIFICIO 13
    public void resolve(List<Player> players) {
        for (Player p : players) {
            if (p.hasBuilding(BuildingType.BUILDING13)) {

            }
        }

    }
}
