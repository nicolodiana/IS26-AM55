import java.util.*;
package it.polimi.ingsw.mesos.MesosGame;
public class Game {
    private List<Player> players;
    private Player currentPlayer;
    private Board sharedBoard;
    private int countRound;

    public Game(){
        players= new ArrayList<Player>();
        countRound=0;
        sharedBoard = new Board(players);
    }
    public void addPlayer(String nickname, String totem, String summaryCardImage){
        players.add(new Player(nickname,totem,summaryCardImage));
    }
    public Player getCurrentPlayer(){
        return currentPlayer;
    }

//    public List<BiddingTicket> getBiddingTicketsFree(){
//        List<BiddingTicket> biddingTrail = sharedBoard.getBiddingTrail();
//        List<BiddingTicket> biddingTicketNotOccupied=new ArrayList<>();
//        for(BiddingTicket ticket:biddingTrail){
//            if(ticket.getPlayer()==null){
//                biddingTicketNotOccupied.add(ticket);
//            }
//        }
//        return  biddingTicketNotOccupied;
//    }
//    public void placeTotem(int index){
//        List<Player> turnOrder = sharedBoard.getTurnTicket().getTurnOrder();
//        List<BiddingTicket> biddingTrail = sharedBoard.getBiddingTrail();
//        int ind=0;
//        if(biddingTrail.get(index).getPlayer()==null){
//            ind =  turnOrder.indexOf(currentPlayer);
//            if(biddingTrail.get(index).getFoodBonus()!=0) currentPlayer.addFood(3);
//            biddingTrail.get(index).setPlayer(currentPlayer);//Game places the current player on specified bidding tile
//        }else{
//            throw new IllegalArgumentException("The index referring to bidding tile has already occupied");
//        }
//        turnOrder.set(ind,null);
//        if(ind < turnOrder.size()-1){
//            currentPlayer = turnOrder.get(ind+1);//Next player i
//            // n the turn
//        }else{
//            for(int i=0;i<biddingTrail.size();i++){
//                if(biddingTrail.get(i).getPlayer()!=null){
//                    currentPlayer = biddingTrail.get(i).getPlayer();
//                    break;
//                }
//            }
//            //The leftmost player will start the first round
//        }
//    }

    public void placeTotem(int index){
        //check if the selected position is taken
        if (sharedBoard.getBiddingTrail().getTicketList().get(index).getIsTaken()){
            throw new IllegalArgumentException("The index referring to bidding tile has already occupied");
        }
        //setupping in the selected position
        sharedBoard.getBiddingTrail().getTicketList().get(index).setIsTaken(true);
        sharedBoard.getBiddingTrail().getTicketList().get(index).setPlayer(currentPlayer);

        System.out.println(currentPlayer.getNickname() + " Moved his Totem to the Bidding Trail");

        //get the next player
        currentPlayer = sharedBoard.getPlayerOrder().getNextPlayerFirstPhase(currentPlayer);

        //check if the next player exist or if the second phase is starting
        if(currentPlayer == null){
            currentPlayer = sharedBoard.getBiddingTrail().getFirstPlayerSecondPhase();

            System.out.println("Second Phase starting\n" + "Now playing: " + currentPlayer.getNickname());
            return;
        }
        System.out.println("Now playing: " + currentPlayer.getNickname());
    }

    //controlli: row , carta ,
    public void pickCard(boolean rowIndex, boolean list, int index) {
        Row row;
        int PlayerPosition = sharedBoard.getBiddingTrail().getPlayerPositionOnTrail(currentPlayer);
        if (rowIndex) {
            if(currentPlayer.getUpperRowCardSelected() == sharedBoard.getBiddingTrail().getTicketList().get(PlayerPosition).getChooseUpperCard()){
                throw new IllegalArgumentException("U can't pick a card from the Upper Row");
            }
            row = sharedBoard.getUpperRow();
        } else {
            if(currentPlayer.getLowerRowCardSelected() == sharedBoard.getBiddingTrail().getTicketList().get(PlayerPosition).getChooseLowerCard()){
                throw new IllegalArgumentException("U can't pick a card from the Lower Row");
            }
            row = sharedBoard.getLowerRow();
        }

        if (list) {
            BuildingCard card = row.getBuildingCardsList().getBuildingDeck().get(index);
            if (!currentPlayer.payFood(card.getFoodCost())){
                throw new IllegalArgumentException("U can't afford this Building card");
            }
            card.addCard(currentPlayer);
            row.getBuildingCardsList().removeBuildingCard(card);
        } else {
            CharacterCard card = row.getCharacterCardsList().get(index);

            //check effect somehow ??!?!?!???!?!!?!?!?!??!?!?!!??!?!?!?!?!?!?!?
            card.addCard(currentPlayer);
            //aggiornare la lista togliendo la carta
            row.removeCharacterCard(card);
        }

        //aggiornare il numero di carte prese dal player dalla determinata riga
        if (rowIndex){
            currentPlayer.addUpperRowCardSelected();
        } else {
            currentPlayer.addLowerRowCardSelected();
        }

        //controllo se il player ha finito le carte che può scegliere
        if  (currentPlayer.getUpperRowCardSelected() == sharedBoard.getBiddingTrail().getTicketList().get(PlayerPosition).getChooseUpperCard() &&
                currentPlayer.getLowerRowCardSelected() == sharedBoard.getBiddingTrail().getTicketList().get(PlayerPosition).getChooseLowerCard()){
            sharedBoard.movePlayerToTurnTicket(currentPlayer);
        currentPlayer = sharedBoard.getBiddingTrail().nextPlayerSecondPhase(currentPlayer, players.size());
        sharedBoard.getBiddingTrail().getTicketList().get(PlayerPosition).removePlayer();
        }

        //controllo se è l'ultimo player
        if (currentPlayer == null){

                //risolvo eventi
                //risolvo effetti
                //restoreForRound
        }

        countRound++;
        if (countRound == 11){
            endGame();
        }
    }

    public void pickFood(){
        int PlayerPosition = sharedBoard.getBiddingTrail().getPlayerPositionOnTrail(currentPlayer);

        //ask if they prefer constant or method invocation
        currentPlayer.addFood(sharedBoard.getBiddingTrail().getTicketList().get(PlayerPosition).getFoodBonus());

        sharedBoard.movePlayerToTurnTicket(currentPlayer);
        currentPlayer = sharedBoard.getBiddingTrail().nextPlayerSecondPhase(currentPlayer, players.size());
        sharedBoard.getBiddingTrail().getTicketList().get(PlayerPosition).removePlayer();

        System.out.println("Now playing: " + currentPlayer.getNickname());

    }


    public void startGame() {
        sharedBoard.initBoard(players);
        byte food=2;
        for(int i=0; i<players.size(); i++){
            sharedBoard.getPlayerOrder().getTurnOrder().get(i).addFood(food);
            if(i%2==0) food++;
        }
        countRound=1;
        currentPlayer = sharedBoard.getPlayerOrder().getTurnOrder().getFirst();

        System.out.println("Now playing: "+currentPlayer.getNickname());
    }

    public void endGame() {
        //resolve all the events

        //end game effects -> calculateWinner
    }

}
