package it.polimi.ingsw.mesos.MesosGame;

public class Player {
    private final String nickname;
    private String totem;
    private int numPP;
    private int numFoods;
    private String summaryCard;
    private int upperRowCardSelected;
    private int lowerRowCardSelected;
    private List<Shaman> shamans;
    private List<Hunter> hunters = new ArrayList<>();
    private List<Artist> artists = new ArrayList<>();
    private List<Collector> collectors = new ArrayList<>();
    private List<Builder> builders = new ArrayList<>();
    private List<Inventor> inventors = new ArrayList<>();
    private List<BuildingCard> buildings;

    public Player(String nickname,String totem, String summaryCard){
        this.nickname = nickname;
        this.totem = totem;
        this.summaryCard = summaryCard;
        this.numFoods = 0;
        this.numPP = 0;
        this.upperRowCardSelected = 0;
        this.lowerRowCardSelected = 0;
        this.shamans = new ArrayList<>();
        this.hunters = new ArrayList<>();
        this.artists = new ArrayList<>();
        this.collectors = new ArrayList<>();
        this.builders = new ArrayList<>();
        this.inventors = new ArrayList<>();
        this.buildings = new ArrayList<>();
    }
    public String getNickname() {
        return nickname;
    }
    public int getNumPP() {
        return numPP;
    }
    public int getNumFoods() {
        return numFoods;
    }
    public String getTotem() {
        return totem;
    }
    public void setTotem(String totem) {
        this.totem = totem;
    }
    public void setNumFoods(int numFoods) {
        this.numFoods = numFoods;
    }
    public void payPP(int amount){
        if(amount<0) throw new IllegalArgumentException("Amount is negative");
        numPP = numPP - amount;
    }
    public void addPP(int amount){
        if(amount<0) throw new IllegalArgumentException("Amount is negative");
        numPP = numPP + amount;
    }
    public void addFood(int amount){
        if(amount<0) throw new IllegalArgumentException("Amount is negative");
        numFoods+=amount;
    }
    public boolean payFood(int amount){
        if(amount<0) throw new IllegalArgumentException("Amount is negative");
        if((numFoods - amount) <0) return false;
        else {// in this case player can transfer food to reserve
            numFoods = numFoods - amount;
            return true;
        }
    }
    public int getUpperRowCardSelected() {
        return upperRowCardSelected;
    }
    public int getLowerRowCardSelected() {
        return lowerRowCardSelected;
    }
    public void addUpperRowCardSelected(){
        upperRowCardSelected++;
    }
    public void addLowerRowCardSelected(){
        lowerRowCardSelected++;
    }
    public void clearRowCardsSelected(){
        upperRowCardSelected = 0;
        lowerRowCardSelected = 0;
    }

    //ADD CARD CON EFFETTI ISTANTANEI
    public void addTribeCard(Shaman card) {
        //card.addCard(card, this);
        shamans.add(card);
    }
    public void addTribeCard(Hunter card) {
        hunters.add(card);
        addFood(1 * (hunters.size() + 1));
    }
    public void addTribeCard(Artist card) {
        artists.add(card);
    }
    public void addTribeCard(Collector card) { collectors.add(card); }
    public void addTribeCard(Builder card) {
        builders.add(card);
    }
    public void addTribeCard(Inventor card) {
        inventors.add(card);
    }
    public void addTribeCard(BuildingCard card) {
        buildings.add(card);
    }
    public List<BuildingCard> getBuildings() {
        return buildings;
    }

    public List<Shaman> getShamansList() {
        return shamans;
    }

    public List<Hunter> getHuntersList() {
        return hunters;
    }

    public List<Inventor> getInventorsList() {
        return inventors;
    }

    public List<Builder> getBuildersList() {
        return builders;
    }

    public List<Collector> getCollectorsList() {
        return collectors;
    }

    public List<Artist> getArtistsList() {
        return artists;
    }

    //questo era per vedere se potevo fare overload senza usare get ndgli altri eventi l'implementazione di è tutta dentro i metodi activate
    public int resolveEvent(ShamanRitual shamanRitual) {
        int totalStars = 0;
        //effetto BUIDING6
        int PPGained = hasBuilding(BuildingType.BUILDING6) ? 3 : 0;

        for (Shaman s : shamans) {
            totalStars += s.getNumStars();
        }
        return totalStars + PPGained;
    }

    public List<BuildingCard> getShamanBuildings() {
        return this.buildings;
    }


    public int playerDeckSize() {
        return shamans.size() + hunters.size() + artists.size() + inventors.size() + builders.size() + collectors.size();
    }

    //DA RIVEDERE PERCHE buidlings CONTINENE BUILDINGCARD NON BUILDINGTYPE QUINDI FARE FOR E CONTROLLARE ATTRIBUTO TYPE
    public Boolean hasBuilding(BuildingType type) {
        if (buildings.contains(type)) return true;

        return false;
    }

    // mi serve per effetto dell'edificio 1 e dell'edificio 11 per trovarmi la minima orccorrenza di carte comune per ogni lista (3 carte per ogni lista = 3 set completi)
    public int minCardSet() {
        int min = shamans.size();
        int huntersSize = hunters.size();
        int collectorsSize = collectors.size();
        int artistsSize = artists.size();
        int buildersSize = builders.size();
        int inventorsSize = inventors.size();

        min = min > huntersSize ? huntersSize : min;
        min = min > collectorsSize ? collectorsSize : min;
        min = min > artistsSize ? artistsSize : min;
        min = min > buildersSize ? buildersSize : min;

        return min > inventorsSize ? inventorsSize : min;
    }


}

