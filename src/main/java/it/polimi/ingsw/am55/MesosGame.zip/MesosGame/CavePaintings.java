package it.polimi.ingsw.mesos.MesosGame;

import java.util.List;

public class CavePaintings extends Event {
    private int upperPP;
    private int lowerPP;
    private int upperNumberOfArtist;
    private int lowerNumberOfArtist;


    public CavePaintings() {
    }

    public CavePaintings(int upperPP, int lowerPP, int upperNumberOfArtist, int lowerNumberOfArtist) {
        this.upperPP = upperPP;
        this.lowerPP = lowerPP;
        this.upperNumberOfArtist = upperNumberOfArtist;
        this.lowerNumberOfArtist = lowerNumberOfArtist;

    }

    @Override
    public void activateEvent(List<Player> players) {
        int counterArtist = 0;

        for (Player p : players) {
            counterArtist = p.getArtistsList().size();

            if (p.hasBuilding(BuildingType.BUILDING10)) p.addFood(counterArtist);

            if (counterArtist == upperNumberOfArtist) p.payPP(counterArtist * upperPP);
            else if (counterArtist == lowerNumberOfArtist) p.addPP(counterArtist * lowerPP);
        }

    }
}