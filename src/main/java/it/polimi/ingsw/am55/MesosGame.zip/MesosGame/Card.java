package it.polimi.ingsw.mesos.MesosGame;

public abstract class Card {
    private int era;

    public int getEra() {
        return era;
    }

    public void addCard(Player player) {}

}
