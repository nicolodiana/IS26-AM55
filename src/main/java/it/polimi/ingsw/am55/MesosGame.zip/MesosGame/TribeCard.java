package it.polimi.ingsw.mesos.MesosGame;

public abstract class  TribeCard extends Card {

    public abstract void addInRightRow(Row upperRow, Row lowerRow);

    public abstract void addInRightList(Row row);
}
