package it.polimi.ingsw.mesos.MesosGame;

public enum BuildingType {
    BUILDING1,
    BUILDING2,
    BUILDING3,
    BUILDING4,
    BUILDING5,
    BUILDING6,
    BUILDING7,
    BUILDING8,
    BUILDING9,
    BUILDING10,
    BUILDING11,
    BUILDING12,
    BUILDING13,
    BUILDING14

}

