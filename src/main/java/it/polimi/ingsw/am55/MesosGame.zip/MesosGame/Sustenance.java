package it.polimi.ingsw.mesos.MesosGame;

import java.util.List;

import static java.lang.Math.abs;

public class Sustenance extends Event {
    private int numPP;

    @Override
    public void activateEvent(List<Player> players) {

        for(Player p : players) {
            int foodDifference = abs((p.getCollectorsList().size() * 3) - p.playerDeckSize());//il numero di collector mi da un costo >= del cibo da pagare
            foodDifference += (p.hasBuilding(BuildingType.BUILDING2) ? 1 : 0) * 1;//non va1 da vedere come gestire questi effetti
            int foodToPay = (foodDifference > 0) ? foodDifference : 0; // caso in cui lo sconto è maggiore del cibo da pagare

            p.payFood(foodToPay);

            if (p.getNumFoods() < 0) {
                p.payPP(numPP * abs(p.getNumFoods())); //l'idea è se sei in negativo sai per quante carte togliere PP e poi lo risetti a 0
                p.setNumFoods(0);
            }
        }
    }
}
