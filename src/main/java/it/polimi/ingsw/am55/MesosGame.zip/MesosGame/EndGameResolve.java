import java.util.List;
package it.polimi.ingsw.mesos.MesosGame;
public class EndGameResolve {

    public void resolve(List<Player> players) {
        int multiplier = 0;

        for (Player p : players) {
            //Effetto fine partita pittori
            p.addPP(p.getArtistsList().size()/2 * 10);

            //Effetto fine partita builders
            int sumPPbuilders = 0;
            multiplier = p.hasBuilding(BuildingType.BUILDING9) ? 2 : 1; //Effetto building 9

            for (Builder b : p.getBuildersList()) {
                sumPPbuilders += b.getNumPP();
            }

            p.addPP(sumPPbuilders * multiplier);

            //Effetto edificio 9
            int bonus9 = p.hasBuilding(BuildingType.BUILDING9) ? 1: 0;
            multiplier = p.getHuntersList().size();

            p.addPP(bonus9 * multiplier);
            p.addFood(bonus9 * multiplier);

            //Effetto edificio 12
            if (p.hasBuilding(BuildingType.BUILDING12)) {

            }

            //Effetto edificio 11
            multiplier = p.hasBuilding(BuildingType.BUILDING9) ? 1 : 0;

            p.addPP(multiplier * p.minCardSet());

            //Effetto edificio 12 vedere se mettere la mappa

            //Effetto edificio 14
            multiplier = p.hasBuilding(BuildingType.BUILDING14) ? 1 : 0;

            p.addPP(25 * multiplier);

            //aggiunta PP dei buildings
            for (BuildingCard buildingCard : p.getBuildings()) {
                p.addPP(buildingCard.getNumOfPP());
            }
        }
    }
}
