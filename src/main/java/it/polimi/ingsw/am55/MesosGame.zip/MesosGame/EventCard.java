package it.polimi.ingsw.mesos.MesosGame;

public class EventCard extends TribeCard {
    private int numPlayer;

    public void addInRightRow(Row upperRow, Row lowerRow){
        upperRow.addEventCard(this);
    }

    public void addInRightList(Row row){
        row.addEventCard(this);
    }
}
