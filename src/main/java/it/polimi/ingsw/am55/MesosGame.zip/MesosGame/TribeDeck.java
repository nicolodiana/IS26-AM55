import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;
package it.polimi.ingsw.mesos.MesosGame;

public class TribeDeck {
    private Stack<TribeCard> tribeCardStack;

    public TribeDeck() {
        tribeCardStack = new Stack<TribeCard>();
    }

    public void initTribeDeck(int numPlayer){

        tribeCardStack.addAll(createFinalEventCards(numPlayer));
        tribeCardStack.addAll(createAllCardsEra3(numPlayer));
        tribeCardStack.addAll(createAllCardsEra2(numPlayer));
        tribeCardStack.addAll(createAllCardsEra1(numPlayer));
    }

    //create all the character and event Card
    private Stack<TribeCard> createAllCardsEra1(int numPlayer) {
        Stack<TribeCard> allCardsEra1 = new Stack<>();
        switch (numPlayer) {
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
            case 5:

                break;
        }
        Collections.shuffle(allCardsEra1);
        return allCardsEra1;
    }
    private List<TribeCard> createAllCardsEra2(int numPlayer) {
        List<TribeCard> allCardsEra2 = new ArrayList<>();
        switch (numPlayer) {
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
            case 5:

                break;
        }
        Collections.shuffle(allCardsEra2);
        return allCardsEra2;
    }
    private List<TribeCard> createAllCardsEra3(int numPlayer) {
        List<TribeCard> allCardsEra3 = new ArrayList<>();
        switch (numPlayer) {
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
            case 5:

                break;
        }
        Collections.shuffle(allCardsEra3);
        return allCardsEra3;
    }
    private List<TribeCard> createFinalEventCards(int numPlayer) {
        List<TribeCard> finalEventCards = new ArrayList<>();
        Collections.shuffle(finalEventCards);
        return finalEventCards;
    }

    public TribeCard getNextCard() {
        return tribeCardStack.pop();
    }
}
