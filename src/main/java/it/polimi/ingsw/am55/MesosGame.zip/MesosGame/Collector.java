package it.polimi.ingsw.mesos.MesosGame;

public class Collector extends Card {
    final private int foodDiscount = 3;

    @Override
    public void addCard(Player player) {
        player.addTribeCard(this);
    }
}
