package it.polimi.ingsw.mesos.provaeffetti_semplice;

public class HuntEventResolver implements EventResolver {

    @Override
    public TriggerType getTrigger() {
        return TriggerType.HUNT_EVENT;
    }

    @Override
    public void resolve(Player player, EventContext ctx) {
        TribeState s = player.getTribeState();
        int hunters = s.getCount(CharacterType.HUNTER);

        if (hunters == 0) return;

        int buildingBonus = s.hasBuilding(8) ? 1 : 0; //aggiungo punto prestigio/cibo addizionale se ho l'edificio 8

        int foodAdded = hunters * (1 + buildingBonus);
        int ppAdded   = hunters * (ctx.getEventCard().getPpGain() + buildingBonus);

        player.addFood(foodAdded);
        player.addPP(ppAdded);

        System.out.println(player.getName() + " [HUNT_EVENT] Cacciatori: " + hunters
                + " -> cibo +" + foodAdded
                + ", PP +" + ppAdded
                + (s.hasBuilding(8) ? " (edificio 8: +1 cibo e +1 PP per cacciatore)" : ""));
    }
}
