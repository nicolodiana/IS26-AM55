package it.polimi.ingsw.mesos.provaeffetti_semplice;

public class PaintingsEventResolver implements EventResolver {

    @Override
    public TriggerType getTrigger() {
        return TriggerType.PAINTINGS_EVENT;
    }

    @Override
    public void resolve(Player player, EventContext ctx) {
        TribeState s = player.getTribeState();
        int artists = s.getCount(CharacterType.ARTIST);
        EventCard card = ctx.getEventCard();
        if (artists==card.getMinArtistNum()) return; //se non hanno numero minimo di artisti termina senza risolvere nulla

        if(s.hasBuilding(10)) player.addFood(artists); //azione edificio 10 se si possiede da 1 cibo al player x ogni artista posseduto

//azioni relative agli artisti posseduti e in relazione con la carta evento pitture rupestri
        if (artists == card.getArtistsUpper()) {
            player.losePP(card.getPpLoss());
            System.out.println(player.getName() + " [PAINTINGS] Artisti: " + artists
                    + " == " + card.getArtistsUpper()
                    + " -> PP -" + card.getPpLoss());

        } else if (artists == card.getArtistsLower()) {
            int ppAdded = artists * card.getPpGain();
            player.addPP(ppAdded);
            System.out.println(player.getName() + " [PAINTINGS] Artisti: " + artists
                    + " >= " + card.getArtistsLower()
                    + " -> PP +" + ppAdded);
        }
    }
}
