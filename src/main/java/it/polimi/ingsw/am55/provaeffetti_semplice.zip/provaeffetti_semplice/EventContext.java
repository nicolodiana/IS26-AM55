package it.polimi.ingsw.mesos.provaeffetti_semplice;

import java.util.List;

// QUESTA E' UNA CLASSE CHE FUNGE DA SOLA LETTURA DELLE INFORMAZIONI NECESSARIE AL PLAYER SUL GIOCO ATTUALE
// PER APPORTARE MODIFICHE DOPO L'EVENTO NOTIFICATO DAL GAME
public class EventContext {
    private final List<Player> players;
    private final EventCard eventCard;      // null se non c'è carta evento (es. END_GAME)
    private final int maxShamanStars;
    private final int minShamanStars;
    //private final Player uniquemax=null; //per gestione edificio 7

    public EventContext(List<Player> players, EventCard eventCard) {
        this.players = players;
        this.eventCard = eventCard;
        boolean unique=false;

        // calcolo fatto UNA VOLTA SOLA qui dentro, serve per saepre globalmente tra tutti i player il valore massimo/minimo di stelle possedute, che poi si userà dentro ogni player
        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;
        for (Player p : players) {
            int stars = p.getTribeState().getShamanStars();
            if (stars > max) max = stars;
            if (stars < min) min = stars;
        }
        this.maxShamanStars = max;
        this.minShamanStars = min;
    }

    public List<Player> getAllPlayers()  { return players; }
    public EventCard getEventCard()      { return eventCard; }
    public int getMaxShamanStars()       { return maxShamanStars; }
    public int getMinShamanStars()       { return minShamanStars; }


}
