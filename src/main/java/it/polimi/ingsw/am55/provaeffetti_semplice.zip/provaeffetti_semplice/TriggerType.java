package it.polimi.ingsw.mesos.provaeffetti_semplice;

// TRIGGER DEGLI EVENTI

public enum TriggerType {
    END_GAME,
    END_TURN,
    END_ROUND,
    HUNT_EVENT,
    PAINTINGS_EVENT,
    RITUAL_EVENT,
    SUSTENANCE_EVENT
}
