package it.polimi.ingsw.mesos.provaeffetti_semplice;

public enum CharacterType {
    INVENTOR, HUNTER, ARTIST, BUILDER, SHAMAN, GATHERER
}
