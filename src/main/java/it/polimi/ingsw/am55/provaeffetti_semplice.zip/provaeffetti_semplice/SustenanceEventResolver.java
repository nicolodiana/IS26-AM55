package it.polimi.ingsw.mesos.provaeffetti_semplice;

public class SustenanceEventResolver implements EventResolver {

    @Override
    public TriggerType getTrigger() {
        return TriggerType.SUSTENANCE_EVENT;
    }

    @Override
    public void resolve(Player player, EventContext ctx) {
        EventCard card = ctx.getEventCard();
        TribeState s = player.getTribeState();

        int numcharacters   = s.getTotalCharacters();   // solo Personaggi, no Edifici
        int gatherers    = s.getCount(CharacterType.GATHERER);
        int discount     = gatherers * 3;               // ogni Raccoglitore -> -3 Cibo
        //applico sconto aggiuntivo pari a num personaggi se ho carta edificio 2
        discount      += s.getTotalCharacters() * (s.hasBuilding(2) ? 1 : 0);
        int foodNeeded   = Math.max(0, numcharacters - discount); //evita che si scelga un foodneeded negativo se ho troppi raccoglitori che mi scontano troppo
        int foodAvail    = player.getFood();

        // se non ho sufficiente cibo x sfamarli, pago tutto il Cibo che ho (non posso scegliere di non pagare) e rimanenti penalizzano con punti prestigio
        int foodPaid     = Math.min(foodAvail, foodNeeded);
        player.payFood(foodPaid);

        int unfed        = foodNeeded - foodPaid;       // Personaggi non sfamati

        if (unfed > 0) {
            int ppLost = unfed * card.getPpLoss();
            player.losePP(ppLost);
            System.out.println(player.getName() + " [SUSTENANCE] Personaggi non sfamati: "
                    + unfed + " -> PP -" + ppLost);
        } else {
            System.out.println(player.getName() + " [SUSTENANCE] Tutti sfamati con "
                    + foodPaid + " Cibo.");
        }
    }
}
