package it.polimi.ingsw.mesos.provaeffetti_semplice;

import java.util.List;
public class RitualEventResolver implements EventResolver {

    @Override
    public TriggerType getTrigger() {
        return TriggerType.RITUAL_EVENT;
    }

    @Override
    public void resolve(Player player, EventContext ctx) {
        EventCard card = ctx.getEventCard();
        TribeState s = player.getTribeState();
        int stars =s.getShamanStars();
        int max   = ctx.getMaxShamanStars();
        int min   = ctx.getMinShamanStars();
        //gestisco effetto edificio 6 durante rituale sciamanico su stelle degli sciamani posseduti
        if (s.hasBuilding(6)) s.ApplyBonusShamanStar();
//Gestisco l'effetto degli Sciamani durante l'evento rituale sciamanico, NOTA: IL CASO DI PARITA' CIOE AD ESEMPIO 3 GIOCATORI CON IL MASSIMO VIENE FATTO AUTOMATICAMENTE
// DATO CHE SCORRO OGNI PLAYER
        if (stars == max)  {
            int ppGain = card.getPpGain();
            if (s.hasBuilding(7)) {
                ppGain += ppGain; //se ho edificio 7 e sono giocatore con massimo di stelle raddoppio il guadagno di PP
            }

            System.out.println(player.getName() + " [RITUAL] Max stelle ("
                    + stars + ") -> PP +" + card.getPpGain());
        }
        if ((stars == min)  && !(s.hasBuilding(3))){ //perche avere l'edificio 3 neutralizza la perdita dei PP
            player.losePP(card.getPpLoss());
            System.out.println(player.getName() + " [RITUAL] Min stelle ("
                    + stars + ") -> PP -" + card.getPpLoss());
        }
    }
}



