package it.polimi.ingsw.mesos.provaeffetti_semplice;
//
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
/*
TribeState è il cuore dello stato aggregato del giocatore.
 Invece di scandire il deck ogni volta che arriva un evento, TribeState mantiene già pronti tutti i contatori
 e le informazioni che i resolver devono leggere.
*/

public class TribeState {
    private final List<Card> tribeDeck = new ArrayList<Card>(); //deck completo per il client
    private final EnumMap<CharacterType, Integer> countsByType =
            new EnumMap<CharacterType, Integer>(CharacterType.class); // contatore per ogni tipo di personaggio
    private final Set<String> inventorIcons = new HashSet<String>();//contatore per le diverse icone invenzione
    private final Set<Integer> ownedBuildingIds = new HashSet<Integer>(); //dice quali tipi di edifici ho( non mi serve contatore perche il gioco non prevede n occorrenze dello stesso tipo)
    private boolean hasBuilding1 = false; //se ho pescato building 1 ad ogni pescaggio devo controllare possibilità di aggiunta 5 cibo quando completo set di 6 carte
    private int  count_differentcard=0;
    private int totalCharacters;                     // totale personaggi (serve al Sostentamento)
    private int shamanStars          ;       // stelle sciamano totali (serve al Rituale)
    private int builderPP                ;           // PP stampati sui Costruttori (serve a fine partita)
    private int builderDiscount         ;            // sconto cibo totale dei Costruttori (serve quando compri edifici)


    public TribeState() {
        for (CharacterType t : CharacterType.values()) {
            countsByType.put(t, 0); //inizializza a 0 il contatore ogni tipo di personaggio (charactertype)
        }
    }

    public void addCard(Card card) { //aggiunge la carta al deck standard
        tribeDeck.add(card);

        if (card instanceof CharacterCard) {  //se a runtime sto aggiungendo una carta personaggio faccio :
            CharacterCard c = (CharacterCard) card;
            totalCharacters++; //aggiorna contatore totale dei personaggi
            if (countsByType.get(c.getType())==1) count_differentcard++; //per tenere traccia delle carte diverse di ogni tipo
            countsByType.put(c.getType(), countsByType.get(c.getType()) + 1); //fa un aumento del contatore (riandando a crearne un altro con nuovo valore) perchè Integer non è mutabile, devo istanziare nuovo oggetto

            switch (c.getType()) {
                case INVENTOR:
                    if (c.getInventionIcon() != null && !c.getInventionIcon().trim().isEmpty()) { //in futuro la stringa si sostituirà con il path dell'icona invenzione
                        inventorIcons.add(c.getInventionIcon().trim().toLowerCase()); //Aggiungo icona invenzione (essendo un Set tiene traccia solo di quelle diverse)
                    }
                    break;
                case SHAMAN:
                    shamanStars += c.getStars(); //mi fornisce il numero di stelle letto dalla carta
                    break;
                case BUILDER:
                    builderPP       += c.getBuilderPP();// mi fornisce il numero di pp prestigio x fine partita
                    builderDiscount += c.getBuilderDiscount(); //mi fornisce lo sconto di pagamento x ogni edificio preso
                    break;
                //PER CACCIATORI, RACCOGLITORI, ARTISTI NON HO BISOGNO DI TENER TRACCIA DI NESSUN ATTRIBUTO AGGREGATO
                default:
                    break;
            }
        }

        if (card instanceof BuildingCard) { //Se la carta è un edificio lo aggiungo al set
            ownedBuildingIds.add(((BuildingCard) card).getBuildingId());
        }
    }
//metodi getter per il deck standard e per le funzioni aggregate
    public int getCount(CharacterType type)     { return countsByType.get(type); }
    public int getTotalCharacters()             { return totalCharacters; }
    public int getShamanStars()                 { return shamanStars; }
    public int getBuilderPP()                   { return builderPP; }
    public int getCount_differentcard()                   { return builderPP; }
    public int getBuilderDiscount()             { return builderDiscount; }
    public int getDistinctInventorIconsCount()  { return inventorIcons.size(); }
    public boolean hasBuilding(int id)          { return ownedBuildingIds.contains(id); }
    public List<Card> getTribeDeck()            { return Collections.unmodifiableList(tribeDeck); }

    //metodi setter per le funzioni aggregate
    public void ApplyBonusShamanStar() {
        shamanStars+=3;
    }


}

