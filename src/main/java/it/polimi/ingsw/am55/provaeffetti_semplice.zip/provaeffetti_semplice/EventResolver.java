package it.polimi.ingsw.mesos.provaeffetti_semplice;

public interface EventResolver {
    TriggerType getTrigger(); //specifica a quale trigger questo resolver  risponde
    void resolve(Player player, EventContext ctx); //contiene la logica vera (effetto)
}
/*
Il vantaggio è che Game può tenere una lista
di EventResolver senza sapere se dentro c'è un HuntEventResolver,
un PaintingsEventResolver o qualsiasi altro: li tratta tutti allo stesso modo e chiama resolve() su ognuno. */