package it.polimi.ingsw.am55.Socket.client;

import com.google.gson.JsonObject;
import it.polimi.ingsw.am55.Socket.VirtualServerSocket;
import jdk.swing.interop.SwingInterOpUtils;


import java.io.*;

public class SocketServerHandler implements VirtualServerSocket {
    final PrintWriter output;


    public SocketServerHandler(PrintWriter output) {
        this.output = output;
    }

    @Override
    public void createGame(String playerID, String totemColor, int numPlayers) {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("nickname", playerID);
        jsonObject.addProperty("color", totemColor);
        jsonObject.addProperty("numPlayers", numPlayers);
        sendJson(jsonObject);
    }

    @Override
    public void joinGame(String playerID, String totemColor) {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("nickname", playerID);
        jsonObject.addProperty("color", totemColor);
        sendJson(jsonObject);
    }

    @Override
    public void placeTotem(String playerID, int index){
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("nickname", playerID);
        jsonObject.addProperty("index", index );
        sendJson(jsonObject);
    }


    @Override
    public void pickCard(int cardID, String playerID){
        sendJson(createJson(playerID, cardID));
    }

    @Override
    public void pickSpecial(int cardID, String playerID) {
        sendJson(createJson(playerID, cardID));

    }
    //Creates json for placetotem, pickcard , pickspecial and pickfood
    private JsonObject createJson(String nickname, int index){
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("nickname", nickname);
        jsonObject.addProperty("cardID", index);
        return jsonObject;
    }

    //Allows to send json on the network from the client to server
    private void sendJson(JsonObject jsonObject){
       if(output != null){
           output.write(jsonObject.toString());
           output.flush();
           if(output.checkError()){
               System.out.println("Error the client could be disconected");
           }
       }else{
           System.out.println("Error the current output stream has not be created");
       }
    }
}
