package it.polimi.ingsw.am55.Socket.client;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class SocketClient {
    private SocketServerHandler server;

    public SocketClient(Socket socket) throws IOException {
        this.server = new SocketServerHandler(new PrintWriter(socket.getOutputStream()));
    }

    public void run(){

        runCli();
    }
    public void runCli(){
        Scanner sc = new Scanner(System.in);
        System.out.println("---WELCOME IN MESOS---");
        System.out.println("Enter your choice: ");
        System.out.println("1. Create Game");
        System.out.println("2. Join Game");
        while(true){
            String command = sc.nextLine();
            if(command.equals("create game")){
                server.createGame(sc.nextLine(),sc.nextLine(),sc.nextInt());
            }
            if(command.equals("join game")){
                server.joinGame(sc.nextLine(),sc.nextLine());
            }
        }

    }
    public static void main(String args[]) throws IOException {
        String ip = "127.0.0.1";
        int port = 4019;

        Socket socketClient = new Socket(ip, port);

        new SocketClient(socketClient).run();
    }
}
