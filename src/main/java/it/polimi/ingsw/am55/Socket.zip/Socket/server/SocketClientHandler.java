package it.polimi.ingsw.am55.Socket.server;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import it.polimi.ingsw.am55.Socket.VirtualViewSocket;
import it.polimi.ingsw.am55.controller.GameController;
import it.polimi.ingsw.am55.message.MessageToClient;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

//Deve contenere un riferimento al controller perché esso servirà ad invocare i metodi del model
// all' interno dei metodi che la classe implementa ad esempio createGame
//Si occupa di accogliere i metodi del client e trasformarli a chiamate verso i metodi nel model attraverso il controller
public class SocketClientHandler implements VirtualViewSocket {
    private ObjectOutputStream outputStream;
    private BufferedReader inputStream;
    private SocketServer server;
    private GameController gameController;
    private Map<String, Command> commands;

    public SocketClientHandler(ObjectOutputStream outputStream,BufferedReader inputStream, SocketServer server,GameController gameController) {
        this.outputStream = outputStream ;
        this.inputStream = inputStream;
        this.server = server;
        this.gameController = gameController;
        commands = new HashMap<>();
        initCommands();

    }
    private JsonObject readFromJson() throws IOException {
        String jsonLine = inputStream.readLine();
        if(jsonLine!=null){
            return new JsonParser().parse(jsonLine).getAsJsonObject();
        }
        return null;
    }
    //Inizziallizzo tutti i comandi che il client può eventualmente invocare, e quali sono le operazioni da compiere
    private void initCommands(){
        commands.put("create game", ()->{
            MessageToClient message = null;
            JsonObject jsonObject = readFromJson();

            if(jsonObject!=null){
                message = this.gameController.createGame(jsonObject.get("nickname").getAsString(),
                        jsonObject.get("color").getAsString(),Integer.parseInt(jsonObject.get("numPlayers").getAsString()));
            }
            return message;
        });
        commands.put("join game", ()->{
            MessageToClient message = null;
            JsonObject jsonObject = readFromJson();
            if(jsonObject!=null){
                message = this.gameController.joinGame(jsonObject.get("nickname").getAsString(),
                        jsonObject.get("color").getAsString());
            }
            return message;
        });
       /* commands.put("place totem", ()->{
            try{
                this.gameController.placetotem(Integer.parseInt(inputStream.readLine()),inputStream.readLine(),);
            }catch(IOException e){
                System.out.println("An error occurred when putting commands in the map");
            }
         });*/
        /*commands.put("pick card", ()->{
            try{
                this.gameController.pickCard(Integer.parseInt(inputStream.readLine()),inputStream.readLine(),);
            }catch(IOException e){
                System.out.println("An error occurred when putting commands in the map");
            }
        });*/
        /*commands.put("pick special", ()->{
            try{
                this.gameController.pickSpecial(Integer.parseInt(inputStream.readLine()),inputStream.readLine(),);
            }catch(IOException e){
                System.out.println("An error occurred when putting commands in the map");
            }
        });*/
        /*commands.put("pick food", ()->{
            try{
                this.gameController.pickFood(Integer.parseInt(inputStream.readLine()),inputStream.readLine(),);
            }catch(IOException e){
                System.out.println("An error occurred when putting commands in the map");
            }
        });*/
        /*commands.put("end game", ()->{
            try{
                this.gameController.EndGame(Integer.parseInt(inputStream.readLine()),inputStream.readLine(),);
            }catch(IOException e){
                System.out.println("An error occurred when putting commands in the map");
            }
        });*/
    }

    //Si occuperà di andare a tradurre i comandi provenienti dal client verso il controller
    public void runVirtualView() throws IOException {
        String command;
        while((command = inputStream.readLine())!=null){
            Command c = commands.get(command);
            c.execute();
        }

    }

    @Override
    public void onMessage(MessageToClient message) throws Exception {

    }
}
