package it.polimi.ingsw.am55.Socket.server;

import it.polimi.ingsw.am55.controller.GameController;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

public class SocketServer {
    private ServerSocket listen;
    private SocketClientHandler clientHandler;
    private List<SocketClientHandler> clients;// List for broadcasting updates
    private GameController gameController;

    public SocketServer(ServerSocket listen) throws IOException {
        this.listen= listen;
        this.gameController = new GameController();

    }

    public void start() throws IOException {
        while(true){
            Socket clientSocket = listen.accept();

            System.out.println("Connection established with" + clientSocket.getInetAddress());

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());

            SocketClientHandler handler = new SocketClientHandler(out,in,this, new GameController());

            synchronized (clients){
                clients.add(handler);
            }
            new Thread(() -> {
                try {
                    handler.runVirtualView();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }).start();
        }
    }
    public static void main(String args[]) throws IOException {
        int port = 4019;
        ServerSocket socket= new ServerSocket(port);// Creazione del socket del server


        new SocketServer(socket).start();// Una volta creato il socket bisogna mandare in esecuzione il server con
        //il metodo start
    }

}
