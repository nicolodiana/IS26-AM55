package it.polimi.ingsw.am55.Socket.server;

import it.polimi.ingsw.am55.message.MessageToClient;

import java.io.IOException;

public interface Command {
    MessageToClient execute() throws IOException;
}
