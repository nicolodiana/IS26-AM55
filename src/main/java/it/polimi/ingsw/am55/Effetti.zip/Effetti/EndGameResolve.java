package it.polimi.ingsw.mesos.Effetti;

import java.util.*;

public class EndGameResolve {

    public void resolve(List<Player> players) {

        for (Player p : players) {

            //Effetto fine partita pittori. Dato che l'operazioni è tra solo int , anche il risultato verrà troncato alla sola parte intera
            //esempio 5:2 = 2 giusto perche con 5 artisti il conbteggio su cui applicare 10 pp sono 2
            p.addPP(p.getArtistsList().size() / 2 * 10);

            //Effetto fine partita builders
            int sumPPbuilders = 0;
            int multiplier = p.hasBuilding(BuildingType.BUILDING9) ? 2 : 1; //Effetto building 9 (raddoppia pp da ottenere x costruttori)
            //conto tutti i PP su ogni carta costruttore posseduta dal Player su cui ciclo
            for (Builder b : p.getBuildersList()) {
                sumPPbuilders += b.getNumPP();
            }
            p.addPP(sumPPbuilders * multiplier);

            /*
            //Effetto edificio 9 ???????? RIDONDANTE
            int bonus9 = p.hasBuilding(BuildingType.BUILDING9) ? 1: 0;
            multiplier = p.getHuntersList().size();

            p.addPP(bonus9 * multiplier);
            p.addFood(bonus9 * multiplier);
            */

            //Effetto fine partita inventori
            int inventorCount = p.getInventorsList().size();
            //creo un set on fly che mi aggiunge solo se l'elemento non è presente (cosi tengo conto delle icone distinte) costo O(n)
            Set<String> distinctIcons = new HashSet<>();
            for (Inventor inventor : p.getInventorsList()) {
                distinctIcons.add(inventor.getIconInvention());
            }
            int inventorPP = inventorCount * distinctIcons.size();
            p.addPP(inventorPP);

            //Effetto edificio 11
            // ATTENZIONE: era BUILDING9 nel codice precedente, corretto in BUILDING11
           // Edificio 11: 6 PP per ogni set completo di 6 personaggi di tipo diverso
            if (p.hasBuilding(BuildingType.BUILDING11)) {
                p.addPP(p.minCardSet() * 6);
            }


            //Effetto edificio 12
            if (p.hasBuilding(BuildingType.BUILDING12)) {
                for (BuildingCard bc : p.getBuildings()) {
                    if (bc.getType().equals(BuildingType.BUILDING12)) {
                        int pptopay = bc.getCharacterForED().countSameTypeIn(p) * bc.getNumOfPP();
                        p.addPP(pptopay);
                        break;
                    }
                }
            }

            //Effetto edificio 14
            multiplier = p.hasBuilding(BuildingType.BUILDING14) ? 1 : 0;
            p.addPP(25 * multiplier);

            /*
            //aggiunta PP dei buildings ??????
            for (BuildingCard buildingCard : p.getBuildings()) {
                p.addPP(buildingCard.getNumOfPP());
            }
            */
        }
    }
}
