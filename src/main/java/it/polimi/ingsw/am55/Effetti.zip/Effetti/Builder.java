package it.polimi.ingsw.mesos.Effetti;

public class Builder extends Card {
    int numPP;
    int pickbuildingdiscount; //sconto che forniscono su ogni edificio

    public Builder(int numPP,int pickbuildingdiscount) {
        this.numPP = numPP;
        this.pickbuildingdiscount = pickbuildingdiscount;
    }

    public int getNumPP() {
        return numPP;
    }
    public int getPickbuildingdiscount() {return pickbuildingdiscount; }

    public void addToPlayer(Player player) {
        //player.getBuildersList().add(this);
        player.addTribeCard(this);
    }
    public int countSameTypeIn(Player player) {
        return player.getBuildersList().size(); // so che sono un Hunter, conto gli Hunter
    }
}
