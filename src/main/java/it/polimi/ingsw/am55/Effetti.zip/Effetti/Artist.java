package it.polimi.ingsw.mesos.Effetti;

public class Artist extends Card {
    @Override
    public void addToPlayer(Player player) {
        //player.getArtistsList().add(this);
        player.addTribeCard(this);
    }
    public int countSameTypeIn(Player player) {
        return player.getArtistsList().size(); // so che sono un Hunter, conto gli Hunter
    }
}
