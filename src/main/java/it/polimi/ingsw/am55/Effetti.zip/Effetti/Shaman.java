package it.polimi.ingsw.mesos.Effetti;
//sciamani
public class Shaman extends Card {
    private int numStars;

    public Shaman(int numStars) {
        this.numStars = numStars;
    }

    @Override
    public void addToPlayer(Player player) {
        //player.getShamansList().add(this);
        player.addTribeCard(this);
    }
    public int countSameTypeIn(Player player) {
        return player.getShamansList().size(); // so che sono un Hunter, conto gli Hunter
    }

    public int getNumStars() {
        return this.numStars;
    }
}
