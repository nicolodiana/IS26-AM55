package it.polimi.ingsw.mesos.Effetti;
//inventori
public class Inventor extends Card {
    private String iconInvention;

    public void addToPlayer(Player player) {
        //player.getInventorsList().add(this);
        player.addTribeCard(this);
    }

    public Inventor(String iconInvention) {
        this.iconInvention = iconInvention;
    }

    public int countSameTypeIn(Player player) {
        return player.getInventorsList().size(); // so che sono un Hunter, conto gli Hunter
    }
    public String getIconInvention() {
        return iconInvention;
    }
}
