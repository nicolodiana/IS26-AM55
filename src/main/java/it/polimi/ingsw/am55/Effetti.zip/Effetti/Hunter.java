package it.polimi.ingsw.mesos.Effetti;
//cacciatori
public class Hunter extends Card {
    private Boolean icon;

    public Hunter(Boolean icon) {
        this.icon = icon;
    }

    public void addToPlayer(Player player) {
        //player.getHuntersList().add(this);
        player.addTribeCard(this);
    }
    public int countSameTypeIn(Player player) {
        return player.getHuntersList().size(); // so che sono un Hunter, conto gli Hunter
    }

    public Boolean getIcon() {
        return icon;
    }
}
