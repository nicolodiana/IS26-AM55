package it.polimi.ingsw.mesos.Effetti;
//raccoglitori
public class Collector extends Card {
    final private int foodDiscount = 3;

    @Override
    public void addToPlayer(Player player) {
        //player.getCollectorsList().add(this);
        player.addTribeCard(this);
    }
}
