package it.polimi.ingsw.mesos.Effetti;

public abstract class Card {

    public void addToPlayer(Player player) {}

//mi serve per contare nel player le occorrenze di una carta il cui tipo concreto è visibile solo a runtime (mi serve x edificio 2)
    public int countSameTypeIn(Player player) {
        return 0; // default: non conta nulla (se mettessi senza implementazione obbliga le carte a definire un implementazione (non devo obbligare le building ad esempio ma solo quelle personaggi)
    }


}
