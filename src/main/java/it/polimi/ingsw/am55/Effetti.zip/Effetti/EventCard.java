package it.polimi.ingsw.mesos.Effetti;

import java.util.List;

public class EventCard {
    public void activateEvent(List<Player> players) {}
}
