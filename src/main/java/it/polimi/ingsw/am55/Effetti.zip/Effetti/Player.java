package it.polimi.ingsw.mesos.Effetti;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Player {
    String nickname;
    private List<Shaman> shamanList;
    private List<Hunter> hunterList = new ArrayList<>();
    private List<Artist> artistList = new ArrayList<>();
    private List<Collector> collectorList = new ArrayList<>();
    private List<Builder> builderList = new ArrayList<>();
    private List<Inventor> inventorList = new ArrayList<>();
    private List<BuildingCard> buildings;
    private int numFood=0;
    private int numPP=0;
    // tiene traccia dell'ultimo set completo completato al momento dell'aggiunta di un personaggio,
    // serve per l'effetto edificio 1: non conta i set già completati prima dell'acquisizione dell'edificio
    private int minSetCompleted;


    public Player(String nickname, int numFood, int numPP) {
        this.nickname = nickname;
        this.shamanList = new ArrayList<>();
        this.hunterList = new ArrayList<>();
        this.artistList = new ArrayList<>();
        this.collectorList = new ArrayList<>();
        this.builderList = new ArrayList<>();
        this.inventorList = new ArrayList<>();
        this.buildings = new ArrayList<>();
        this.numFood = numFood;
        this.numPP = numPP;
        this.minSetCompleted = 0;
    }

    // Edificio 1 (effetto passivo su pescaggio personaggi):
    // Dal momento in cui si possiede BUILDING1, si guadagnano 5 cibi ogni volta che
    // si completa un nuovo set di 6 carte personaggio di tipo diverso (1 per tipo).
    // Non conta i set già completati prima dell'acquisizione dell'edificio:
    // quando si acquisisce BUILDING1, minSetCompleted viene allineato al valore attuale
    // di minCardSet() cosi i set già fatti non vengono premiati.
    // Ad ogni aggiunta di personaggio si controlla se minCardSet() è aumentato
    // rispetto a minSetCompleted: se sì, si è completato un nuovo set e si aggiungono 5 cibi.
  public  void checkBuilding1() {
        if (hasBuilding(BuildingType.BUILDING1)) {
            int currentSet = minCardSet();
            if (currentSet > minSetCompleted) {
                addFood(5);
                minSetCompleted = currentSet;
            }
        }
    }

    //ADD CARD CON EFFETTI ISTANTANEI
    public void addTribeCard(Shaman card) {
        //card.addCard(this);
        shamanList.add(card);
        checkBuilding1();
    }

    public void addTribeCard(Hunter card) {
        //card.addCard(this);
        //aggiunge cacciatore e se ha icona si guadagna 1 cibo x ogni cacciatore in tribù (effetto istantaneo)
        hunterList.add(card);
        if (card.getIcon()) { addFood(1 * (hunterList.size())); }
        checkBuilding1();
    }

    public void addTribeCard(Artist card) {
        //card.addCard(this);
        artistList.add(card);
        checkBuilding1();
    }

    public void addTribeCard(Collector card) {
        //card.addCard(this);
        collectorList.add(card);
        checkBuilding1();
    }

    // Il suo ppBonus viene conteggiato a fine partita da EndGameResolver.
    public void addTribeCard(Builder card) {
        //card.addCard(this);
        builderList.add(card);
        checkBuilding1();
    }

    public void addTribeCard(Inventor card) {
        //Effetto edificio 5
        if (hasBuilding(BuildingType.BUILDING5)) {
            int countEqualsInvontors = 0;
            //equalsIgnoreCase controlla prima dell'aggiunta se 2 stringhe (invenzione) (poi json) sono uguali, ignorando uppercase e formattazione stringa
            for (Inventor inventor : inventorList) {
                if (inventor.getIconInvention().equalsIgnoreCase(card.getIconInvention())) { countEqualsInvontors++; }
            }
            // se prima dell'aggiunta erano dispari, con questa carta completo una nuova coppia
            // e quindi guadagno 3 cibi.
            addFood((countEqualsInvontors % 2 == 1) ? 3 : 0);
        }
        //card.addCard(this);
        inventorList.add(card);
        checkBuilding1();
    }

    public void addTribeCard(BuildingCard card) {
        try {
            int builderDiscount = 0;
            //calcolo costo degli sconti in base ai costruttori che ho
            for (Builder b : builderList) {
                builderDiscount += b.getPickbuildingdiscount();
            }

            int buildingCost = card.getFoodCost() - builderDiscount;
            buildingCost = Math.max(0, buildingCost); //se lo sconto è maggiore del costo dovuto, setto un minimo di 0

            if (this.getNumFood() < buildingCost) { //se non ho abbastanza cibo non la prendo e lancio eccezione poi inviata anche alla view
                throw new IllegalArgumentException("Non puoi pescarla!");
            }

            this.removeFood(buildingCost);
            buildings.add(card);

            // se la building card appena aggiunta è BUILDING1,
            // allinea minSetCompleted ai set già completati così non li conta retroattivamente
            if (card.getType().equals(BuildingType.BUILDING1)) {
                minSetCompleted = minCardSet();
            }

        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    //METODI ADD E REMOVE PP E FOOD
    public void addFood(int numFood) {
        this.numFood += numFood;
    }

    public void addPP(int numPP) {
        this.numPP += numPP;
    }

    public void removeFood(int numFood) {
        this.numFood -= numFood;
    }

    public void removePP(int numPP) {
        this.numPP -= numPP;
    }

    //METODI GET
    public String getNickname() {
        return nickname;
    }

    public List<BuildingCard> getBuildings() {
        return buildings;
    }

    public int getNumPP() {
        return numPP;
    }

    public int getNumFood() {
        return numFood;
    }

    public List<Shaman> getShamansList() {
        return shamanList;
    }

    public List<Hunter> getHuntersList() {
        return hunterList;
    }

    public List<Inventor> getInventorsList() {
        return inventorList;
    }

    public List<Builder> getBuildersList() {
        return builderList;
    }

    public List<Collector> getCollectorsList() {
        return collectorList;
    }

    public List<Artist> getArtistsList() {
        return artistList;
    }

    public List<BuildingCard> getShamanBuildings() {
        return this.buildings;
    }

    public int playerDeckSize() {
        return shamanList.size() + hunterList.size() + artistList.size() + inventorList.size() + builderList.size() + collectorList.size();
    }

    //DA RIVEDERE PERCHE buildings CONTIENE BUILDINGCARD NON BUILDINGTYPE QUINDI FARE FOR E CONTROLLARE ATTRIBUTO TYPE
    public Boolean hasBuilding(BuildingType type) {
        for (BuildingCard bc : buildings) {
            if (bc.type.equals(type)) { return true; }
        }
        return false;
    }

    //metodo per contare il totale di stelle possedute guardando gli sciamani nel mio deck (serve x rituale sciamanico)
    //considera anche l'aggiunta di 3 stelle finali se si ha edificio 6
    public int countShamanStars() {
        int totalStars = 0;
        for (Shaman s : shamanList) {
            totalStars += s.getNumStars();
        }
        if (hasBuilding(BuildingType.BUILDING6)) {
            totalStars += 3;
        }
        return totalStars;
    }

    // mi serve per effetto dell'edificio 1 e dell'edificio 11 per trovarmi la minima occorrenza di carte comune per ogni lista (3 carte per ogni lista = 3 set completi)
    public int minCardSet() {
        return Collections.min(Arrays.asList(
                shamanList.size(),
                hunterList.size(),
                artistList.size(),
                collectorList.size(),
                builderList.size(),
                inventorList.size()
        ));
    }
}
