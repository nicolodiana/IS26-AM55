package it.polimi.ingsw.am55.view.gui;

import it.polimi.ingsw.am55.ClientModel.ClientModel;
import it.polimi.ingsw.am55.MesosModel.Enum.GameState;
import it.polimi.ingsw.am55.controller.UserActionHandler;
import it.polimi.ingsw.am55.dto.GameView;
import it.polimi.ingsw.am55.dto.LobbyView;
import it.polimi.ingsw.am55.dto.endgame.EndGameResultView;
import it.polimi.ingsw.am55.view.ClientAction;
import it.polimi.ingsw.am55.view.ClientActionResolver;
import it.polimi.ingsw.am55.view.ClientModelObserver;
import it.polimi.ingsw.am55.view.gui.scene.EndGameSceneController;
import it.polimi.ingsw.am55.view.gui.scene.GameSceneController;
import it.polimi.ingsw.am55.view.gui.scene.GenericSceneController;
import it.polimi.ingsw.am55.view.gui.scene.LobbySceneController;
import it.polimi.ingsw.am55.view.gui.scene.QuitGameSceneController;
import javafx.application.Platform;

import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * JavaFX implementation of the client view.
 * <p>
 * This class observes {@link ClientModel}, chooses the correct scene, and delegates
 * rendering details to FXML controllers. Controller commands are executed on a
 * dedicated background thread so the JavaFX application thread stays responsive.
 */
public class GuiView implements ClientModelObserver {

    private static final String EVENT_RESOLUTION_START_MESSAGE = "Event resolution is starting...";

    private final ClientModel model;
    private final ClientActionResolver actionResolver;
    private final ExecutorService commandExecutor;

    private UserActionHandler actionHandler;
    private volatile GameView currentGameView;
    private volatile String currentInfoMessage;
    private volatile String currentErrorMessage;
    private volatile boolean waitingServerResponse;
    private volatile String playerId;
    private volatile boolean inLobby = true;
    private volatile LobbyView currentLobbyView;
    private volatile boolean startGameRequested;

    /**
     * Creates a GUI view bound to a client model.
     *
     * @param model observed client model
     */
    public GuiView(ClientModel model) {
        this.model = Objects.requireNonNull(model, "model");
        this.actionResolver = new ClientActionResolver();
        this.commandExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(r);
            thread.setName("GUI-Command-Thread");
            thread.setDaemon(true);
            return thread;
        });
    }

    /**
     * Injects the command handler used to send player actions to the server.
     *
     * @param actionHandler controller-facing action handler
     */
    public void setActionHandler(UserActionHandler actionHandler) {
        this.actionHandler = actionHandler;
    }

    /**
     * Returns the nickname selected by the local player.
     *
     * @return local player nickname, or {@code null} before create/join
     */
    public String getPlayerId() {
        return playerId;
    }

    /**
     * Shows the start scene on the JavaFX application thread.
     */
    public void showInitialScene() {
        Platform.runLater(SceneManager::showStartScene);
    }

    /**
     * Lets the player leave the splash scene and synchronize with the lobby state.
     */
    public void startGameFromInitialScene() {
        startGameRequested = true;

        if (currentLobbyView != null) {
            renderCurrentState();
            showPendingMessages();
            return;
        }

        if (SceneManager.isCurrentScene(GuiSceneType.START)) {
            showInfo("Synchronizing lobby with the server...");
        }
    }

    /**
     * Receives model updates and refreshes the correct scene.
     */
    @Override
    public void onModelChanged(ClientModel updatedModel) {
        Platform.runLater(() -> {
            boolean wasInLobbyWithStartedGame = inLobby
                    && currentLobbyView != null
                    && currentLobbyView.getGameState() != null
                    && currentLobbyView.getGameState() != GameState.CREATED;

            waitingServerResponse = false;
            currentErrorMessage = updatedModel.getLastError();
            currentInfoMessage = updatedModel.getStateRequest();
            currentGameView = updatedModel.getGameView();
            inLobby = updatedModel.isInLobby();
            currentLobbyView = updatedModel.getLobbyView();

            if (wasInLobbyWithStartedGame
                    && currentInfoMessage != null
                    && currentInfoMessage.toLowerCase().contains("uscito correttamente")) {
                showTerminalMessage("You left the lobby successfully."
                        + "\nThe game had already started and was not accepting new players.");
                return;
            }

            if (SceneManager.isCurrentScene(GuiSceneType.QUIT_GAME)) {
                updateTerminalStatus();
                return;
            }

            if (!startGameRequested && inLobby) {
                if (SceneManager.isCurrentScene(GuiSceneType.START)
                        && currentInfoMessage != null
                        && !currentInfoMessage.isBlank()) {
                    showInfo("Press START GAME to enter the lobby.");
                }
                return;
            }

            renderCurrentState();
            showPendingMessages();
        });
    }

    /**
     * Updates the terminal scene without navigating away from it.
     */
    private void updateTerminalStatus() {
        GenericSceneController controller = SceneManager.getActiveController();
        if (controller == null) {
            return;
        }
        if (currentErrorMessage != null && !currentErrorMessage.isBlank()) {
            controller.showStatus(currentErrorMessage);
        } else if (currentInfoMessage != null && !currentInfoMessage.isBlank()) {
            controller.showStatus(currentInfoMessage);
        }
    }

    /**
     * Checks whether the lobby is already past the joinable CREATED state.
     */
    private boolean isLobbyGameAlreadyStarted() {
        return currentLobbyView != null
                && currentLobbyView.getGameState() != null
                && currentLobbyView.getGameState() != GameState.CREATED;
    }

    /**
     * Leaves the lobby automatically when the server says the game has already started.
     */
    private void leaveLobbyBecauseGameAlreadyStarted() {
        if (waitingServerResponse || actionHandler == null) {
            return;
        }

        waitingServerResponse = true;
        commandExecutor.submit(() -> {
            try {
                actionHandler.onQuitSelectedLobby();
            } catch (RuntimeException e) {
                Platform.runLater(() -> {
                    waitingServerResponse = false;
                    showTerminalMessage("Error while leaving the lobby: " + e.getMessage());
                });
            }
        });
    }

    /**
     * Routes the current model snapshot to the proper scene.
     */
    private void renderCurrentState() {
        ClientAction crashAction = actionResolver.resolve(currentGameView, playerId, inLobby, model.isGameCrashed());
        if (crashAction == ClientAction.CRASHED) {
            showTerminalMessage(nonBlankOrDefault(currentInfoMessage, "The connection is closed."));
            return;
        }

        if (inLobby) {
            if (isLobbyGameAlreadyStarted()) {
                leaveLobbyBecauseGameAlreadyStarted();
                return;
            }
            showLobby(false);
            return;
        }

        EndGameResultView result = model.getEndGameResultView();
        if (result != null) {
            showEndGame(result);
            return;
        }

        ClientAction action = actionResolver.resolve(currentGameView, playerId, false, model.isGameCrashed());
        switch (action) {
            case LOBBY -> showLobby(false);
            case WAITING_TO_START -> showLobby(true);
            case END_GAME -> {
                EndGameResultView endGameResult = model.getEndGameResultView();
                if (endGameResult != null) {
                    showEndGame(endGameResult);
                } else {
                    showTerminalMessage(nonBlankOrDefault(currentInfoMessage, "The game has ended."));
                }
            }
            case CRASHED -> showTerminalMessage(nonBlankOrDefault(currentInfoMessage, "The connection is closed."));
            default -> showGame(currentGameView, action);
        }
    }

    /**
     * Shows the terminal scene used for quit and crash messages.
     */
    private void showTerminalMessage(String message) {
        SceneManager.showQuitGameScene();
        QuitGameSceneController controller = (QuitGameSceneController) SceneManager.getActiveController();
        controller.render(message);
    }

    /**
     * Shows the lobby scene and renders the latest lobby state.
     */
    private void showLobby(boolean locked) {
        SceneManager.showLobbySceneIfNeeded();
        LobbySceneController controller = (LobbySceneController) SceneManager.getActiveController();
        controller.renderLobby(currentLobbyView, locked || waitingServerResponse);

        if (locked) {
            controller.lockInteractions(nonBlankOrDefault(
                    currentInfoMessage,
                    "Game created. Waiting for the other players..."
            ));
        }
    }

    /**
     * Shows the game scene and renders the latest game board.
     */
    private void showGame(GameView gameView, ClientAction action) {
        if (gameView == null) {
            showLobby(false);
            return;
        }

        SceneManager.showGameSceneIfNeeded();
        GameSceneController controller = (GameSceneController) SceneManager.getActiveController();
        controller.render(gameView, action, playerId, waitingServerResponse);

        if (EVENT_RESOLUTION_START_MESSAGE.equals(currentInfoMessage)) {
            controller.showStatus("Event resolution in progress...");
        }
    }

    /**
     * Shows the end-game scene and renders final results.
     */
    private void showEndGame(EndGameResultView result) {
        SceneManager.showEndGameScene();
        EndGameSceneController controller = (EndGameSceneController) SceneManager.getActiveController();
        controller.render(result, currentGameView);
    }

    /**
     * Displays pending info or error messages on the active scene.
     */
    private void showPendingMessages() {
        if (currentErrorMessage != null && !currentErrorMessage.isBlank()) {
            showError(currentErrorMessage);
            return;
        }
        if (currentInfoMessage != null && !currentInfoMessage.isBlank()) {
            showInfo(currentInfoMessage);
        }
    }

    /**
     * Sends an info message to the active scene controller.
     */
    private void showInfo(String message) {
        GenericSceneController controller = SceneManager.getActiveController();
        if (controller != null) {
            controller.showStatus(message);
        }
    }

    /**
     * Sends an error message to the active scene controller.
     */
    private void showError(String message) {
        GenericSceneController controller = SceneManager.getActiveController();
        if (controller != null) {
            controller.showError(message);
        }
    }

    /**
     * Requests to leave the current game.
     */
    public void quitGame() {
        if (!ensureActionHandler() || playerId == null) {
            return;
        }
        submitCommand(() -> actionHandler.onQuitGameSelected(playerId));
    }

    /**
     * Requests to leave the lobby.
     */
    public void quitLobby() {
        if (!ensureActionHandler()) {
            return;
        }
        showTerminalMessage("Leaving the lobby...");
        submitCommand(() -> actionHandler.onQuitSelectedLobby());
    }

    /**
     * Sends a create-game command.
     */
    public void createGame(String playerId, String totemColor, int numPlayers) {
        if (!ensureActionHandler()) {
            return;
        }
        this.playerId = playerId.trim();
        submitCommand(() -> actionHandler.onCreateGameSelected(this.playerId, totemColor, numPlayers));
    }

    /**
     * Sends a join-game command.
     */
    public void joinGame(String playerId, String totemColor) {
        if (!ensureActionHandler()) {
            return;
        }
        this.playerId = playerId.trim();
        submitCommand(() -> actionHandler.onJoinGameSelected(this.playerId, totemColor));
    }

    /**
     * Sends a totem-placement command.
     */
    public void placeTotem(int ticketIndex) {
        if (!ensureActionHandler()) {
            return;
        }
        submitCommand(() -> actionHandler.onPlaceTotemSelected(this.playerId, ticketIndex));
    }

    /**
     * Sends a standard card-pick command.
     */
    public void pickCard(int cardId) {
        if (!ensureActionHandler() || playerId == null) {
            return;
        }
        submitCommand(() -> actionHandler.onPickCardSelected(playerId, cardId));
    }

    /**
     * Sends a special card-pick command.
     */
    public void pickSpecial(int cardId) {
        if (!ensureActionHandler() || playerId == null) {
            return;
        }
        submitCommand(() -> actionHandler.onPickSpecialSelected(playerId, cardId));
    }

    /**
     * Runs a server command off the JavaFX thread and locks the active scene until the next update.
     */
    private void submitCommand(Runnable command) {
        waitingServerResponse = true;
        GenericSceneController controller = SceneManager.getActiveController();
        if (controller != null) {
            controller.lockInteractions("Command sent. Waiting for the server...");
        }

        commandExecutor.submit(() -> {
            try {
                command.run();
            } catch (RuntimeException e) {
                Platform.runLater(() -> {
                    waitingServerResponse = false;
                    showError(e.getMessage());
                });
            }
        });
    }

    /**
     * Verifies that the command handler dependency is available.
     */
    private boolean ensureActionHandler() {
        if (actionHandler != null) {
            return true;
        }
        showError("Action handler is not configured: the command cannot be sent.");
        return false;
    }

    /**
     * Returns a fallback when a message is blank.
     */
    private String nonBlankOrDefault(String message, String fallback) {
        return message == null || message.isBlank() ? fallback : message;
    }

    /**
     * Stops the background command executor.
     */
    public void shutdown() {
        commandExecutor.shutdownNow();
    }
}
