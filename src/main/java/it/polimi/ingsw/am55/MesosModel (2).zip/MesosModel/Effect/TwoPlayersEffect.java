package it.polimi.ingsw.am55.MesosModel.Effect;

import it.polimi.ingsw.am55.MesosModel.Player.Player;

public class TwoPlayersEffect extends TurnOrderEffect {
    @Override
    public void applyFood(Player player,int index) {
        if(index==0){
            player.addFood(1);
        }
    }
}
