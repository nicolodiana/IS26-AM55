package it.polimi.ingsw.am55.MesosModel.Game;

import it.polimi.ingsw.am55.MesosModel.Exceptions.GameAlreadyStarted;
import it.polimi.ingsw.am55.MesosModel.Exceptions.NicknameAlreadyUsed;
import it.polimi.ingsw.am55.MesosModel.Exceptions.PlayerNumberOutOfRange;
import it.polimi.ingsw.am55.MesosModel.Exceptions.TotemAlreadyUsed;


/**
 * This interface contains all methods can be called by Controller
 **/
public interface GameController {

    /**
     * Returns the game's id
     * @return game's id
    **/
    public String getIdGame();
    /**
     * Allows all client player getting into the game
     * @throws PlayerNumberOutOfRange if the number of players is out between 2 and 5
     * @throws NicknameAlreadyUsed the nickname is already used
     * @throws TotemAlreadyUsed if the totem is already used
     * @throws GameAlreadyStarted if the game is already used
     *
     * **/
    public void joinGame(String nickname, String totem, String summaryCardImage)
            throws PlayerNumberOutOfRange,NicknameAlreadyUsed,TotemAlreadyUsed,GameAlreadyStarted,IllegalArgumentException;

    /**
     * Return if the game is started
     * @return true if the game is started
     **/
    public boolean isStarted();

    /**
     * A client player can create a new game
    **/
    public void createGame(int numPlayers);
    /**
     * Allows to start a new game
     * @return true if the game has been started correctly
     *
    public boolean start();**/

    /**
     * Allows to have the current player in the game
     * @return current player's nickname
     **/
    public String getCurrentPlayer();

    /**
     * Allows to client player places his totem on the board
     * @param index the index of the totem on bidding ticket
     * @throws IllegalArgumentException if the bidding ticket has been taken
     * */
    public void placeTotem(int index) throws IllegalArgumentException;

    /**
     * Send the winner or winners to the views
    **/
    public void getWinner();

    /**
     * Allows for a client player gets foods
     * @throws IllegalStateException if it will be when there are less than 5 players
     **/
    public void pickFood() throws IllegalStateException;

    /**
     * Allows end the game
     **/
    public void endGame();
}
