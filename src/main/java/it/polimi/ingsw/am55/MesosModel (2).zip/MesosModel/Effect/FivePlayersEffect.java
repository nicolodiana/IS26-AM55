package it.polimi.ingsw.am55.MesosModel.Effect;

import it.polimi.ingsw.am55.MesosModel.Player.Player;

public class FivePlayersEffect extends TurnOrderEffect {
    @Override
    public void applyFood(Player player, int index) {
        if(index==0){
            player.addFood(3);
        }else if(index==1){
            player.addFood(1);
        }
    }
}
