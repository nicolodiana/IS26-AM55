package it.polimi.ingsw.am55.network;

import it.polimi.ingsw.am55.controller.GameController;
import it.polimi.ingsw.am55.message.MessageDelivery;
import it.polimi.ingsw.am55.message.MessageToClient;
import it.polimi.ingsw.am55.network.command.ServerCommand;
import it.polimi.ingsw.am55.virtualview.VirtualServer;
import it.polimi.ingsw.am55.virtualview.VirtualView;

import java.util.HashMap;
import java.util.Map;
//metto i synchronized per evitare richieste concorrent
public class ServerApplication implements VirtualServer, MessageDelivery {

    private final GameController controller;
    private final Map<String, VirtualView> clients;

    public ServerApplication() {
        this.controller = new GameController();
        this.clients = new HashMap<>();
    }

    public void registerClient(String playerId, VirtualView client) {
        synchronized (clients) {
            clients.put(playerId, client);
        }
    }

    public void executeCommand(ServerCommand command, VirtualView sender) throws Exception {
        command.execute(this, sender);
    }

    @Override
    public synchronized void createGame(String playerId, String totemColor, int numPlayers) throws Exception {
        MessageToClient message = controller.createGame(playerId, totemColor, numPlayers);
        message.deliver(playerId, this);
    }

    @Override
    public synchronized void joinGame(String playerId, String totemColor) throws Exception {
        MessageToClient message = controller.joinGame(playerId, totemColor);
        message.deliver(playerId, this);
    }

    @Override
    public synchronized void placeTotem(String playerId, int index) throws Exception {
        MessageToClient message = controller.placeTotem(playerId, index);
        message.deliver(playerId, this);
    }

    public synchronized void pickCard(String playerId, int cardId) throws Exception {
        MessageToClient message = controller.pickCard(playerId, cardId);
        message.deliver(playerId, this);
    }

    public synchronized void pickSpecial(String playerId, int cardId) throws Exception {
        MessageToClient message = controller.pickSpecial(playerId, cardId);
        message.deliver(playerId, this);
    }

    @Override
    public void sendTo(String playerId, MessageToClient message) {
        VirtualView client;

        synchronized (clients) {
            client = clients.get(playerId);
        }

        if (client == null) {
            return;
        }

        try {
            client.onMessage(message);
        } catch (Exception e) {
            System.out.println("Client disconnesso durante invio mirato.");
        }
    }

    @Override
    public void broadcast(MessageToClient message) {
        Map<String, VirtualView> copy;

        synchronized (clients) {
            copy = new HashMap<>(clients);
        }

        for (VirtualView client : copy.values()) {
            try {
                client.onMessage(message);
            } catch (Exception e) {
                System.out.println("Client disconnesso durante broadcast.");
            }
        }
    }
}