package it.polimi.ingsw.am55.Socket;

import com.google.gson.JsonObject;
import it.polimi.ingsw.am55.Socket.server.SocketClientHandler;

public class CommandRequest {
    private SocketClientHandler sender;
    private JsonObject command;

    public CommandRequest(SocketClientHandler sender, JsonObject command) {
        this.sender = sender;
        this.command = command;
    }

    public  SocketClientHandler getSender() {
        return sender;
    }
    public String getCommand() {
        return command.get("command").getAsString();
    }
    public JsonObject getParameters() {
        return command.get("parameters").getAsJsonObject();
    }
}
