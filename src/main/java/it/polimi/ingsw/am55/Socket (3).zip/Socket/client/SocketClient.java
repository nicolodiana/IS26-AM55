package it.polimi.ingsw.am55.Socket.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import it.polimi.ingsw.am55.ClientModel.CliModel;
import it.polimi.ingsw.am55.message.MessageToClient;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class SocketClient {
    private SocketServerHandler server; //Translate the command from CLI/GUI to object to send accross the network
    private CliModel model;
    private final ObjectInputStream input; //The clients shuold read object messages from their stream

    public SocketClient(Socket socket,CliModel model,ObjectInputStream input) throws IOException {
        this.server = new SocketServerHandler(new PrintWriter(socket.getOutputStream()));
        this.model = model;
        this.input = input;
    }

    private void run() {
        new Thread(() -> {
            try {
                runVirtualServer();//Da un lato devo ascoltare i comandi provenienti dal server
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).start();
        runCli();//Dall' altro devo ascoltare i comandi provenienti dal client
    }

    // comunicazione dal server al client
    private void runVirtualServer() throws IOException, ClassNotFoundException {
        MessageToClient command ;
        while ((command = (MessageToClient) input.readObject()) != null) {
            synchronized (model){
                command.update(model);
            }
        }
    }

    /*TODO Capire come fare in modo che se due o più client fanno richiesta dello stesso comando nulla vada in crash
    inoltre gestire anche il caso in cui contemporaneamente richiedono comandi diversi (coda di comandi)
    */
    public void runCli(){
        Scanner sc = new Scanner(System.in);
        System.out.println("---WELCOME IN MESOS---");
        System.out.println("Enter your choice: ");
        System.out.println("1. Create Game");
        System.out.println("2. Join Game");
        while(true){
            String command = sc.nextLine();
            if(command.equals("create game")){
                server.createGame(sc.nextLine(),sc.nextLine(),sc.nextInt());
            }
            if(command.equals("join game")){
                server.joinGame(sc.nextLine(),sc.nextLine());
            }
        }

    }
    public static void main(String args[]) throws IOException {
        String ip = "127.0.0.1";
        int port = 4019;

        Socket socketClient = new Socket(ip, port);

        CliModel model = new CliModel();

        new SocketClient(socketClient,model,new ObjectInputStream(socketClient.getInputStream())).run();
    }
}
