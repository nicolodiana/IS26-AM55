package it.polimi.ingsw.am55.Socket.server;

import it.polimi.ingsw.am55.controller.GameController;
import it.polimi.ingsw.am55.message.MessageDelivery;
import it.polimi.ingsw.am55.message.MessageDeliverySocket;
import it.polimi.ingsw.am55.message.MessageToClient;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class SocketServer {
    private ServerSocket listen; //Server uses it to accept clients
    private SocketClientHandler clientHandler;
    private final GameController gameController;
    private final TCPManager tcpManager; //Handler tcp connection

    public SocketServer(ServerSocket listen) throws IOException {
        this.listen= listen;
        this.gameController = new GameController();
        this.tcpManager = new TCPManager(gameController);
    }

    public void start() throws IOException {
        tcpManager.startDispatcher(); //Dispatcher is used to execute command from clients
        while(true){
            Socket clientSocket = listen.accept();

            System.out.println("Connection established with" + clientSocket.getInetAddress());

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());

            //Client handler allows to send and recieve commands from/to client
            SocketClientHandler handler = new SocketClientHandler(clientSocket,out,in,tcpManager);

            tcpManager.registerHandler(handler);

            new Thread(() -> {
                try {
                    handler.runVirtualView();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }).start();
        }
    }

    public static void main(String args[]) throws IOException {
        int port = 4019;
        ServerSocket socket= new ServerSocket(port);// Creazione del socket del server


        new SocketServer(socket).start();// Una volta creato il socket bisogna mandare in esecuzione il server con
        //il metodo start
    }
}
