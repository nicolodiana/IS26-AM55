package it.polimi.ingsw.am55.Socket.server;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import it.polimi.ingsw.am55.Socket.CommandRequest;
import it.polimi.ingsw.am55.Socket.InvalidCommandException;
import it.polimi.ingsw.am55.Socket.VirtualViewSocket;
import it.polimi.ingsw.am55.controller.GameController;
import it.polimi.ingsw.am55.message.ErrorMessage;
import it.polimi.ingsw.am55.message.MessageToClient;

import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/****/
public class SocketClientHandler implements VirtualViewSocket {
    private final ObjectOutputStream outputStream;
    private final BufferedReader inputStream;
    private final TCPManager tcpManager;
    private final Socket socketClient;
    private String playerId;

    public SocketClientHandler(Socket socketClient, ObjectOutputStream outputStream,BufferedReader inputStream, TCPManager tcpManager) {
        this.socketClient = socketClient;
        this.outputStream = outputStream ;
        this.inputStream = inputStream;
        this.tcpManager = tcpManager;

    }
    private JsonObject readFromJson() throws IOException {
        String jsonLine = inputStream.readLine();
        if(jsonLine!=null){
            return new JsonParser().parse(jsonLine).getAsJsonObject();
        }
        return null;
    }
    public String getPlayerId() {return playerId;}
    //Si occuperà di andare a tradurre i comandi provenienti dal client verso il controller
    public void runVirtualView() throws IOException {
        JsonObject command ;
        while((command = readFromJson())!=null){
            try{
                if(!command.has("command")){
                    throw new InvalidCommandException("The command requested is invalid");
                }
                CommandRequest commandRequest = new CommandRequest(this,command);
                tcpManager.enqueueCommandRequest(commandRequest);
            }catch(Exception e){
                e.getStackTrace();
            }
        }

    }

    @Override
    public synchronized void onMessage(MessageToClient message) throws Exception {
        if (message == null) {
            return;
        }
        outputStream.reset();
        outputStream.writeObject(message);
        outputStream.flush();
    }
    public void closeVirtualView() throws IOException {
        try{
            socketClient.close();
        }catch(IOException e){
            System.out.println("Error closing stream");
        }
    }
}
