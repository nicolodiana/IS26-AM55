package it.polimi.ingsw.am55.Socket.server;

import com.google.gson.JsonObject;
import it.polimi.ingsw.am55.controller.GameController;
import it.polimi.ingsw.am55.message.MessageDeliverySocket;
import it.polimi.ingsw.am55.message.MessageToClient;
import it.polimi.ingsw.am55.Socket.CommandRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.function.Function;

public class TCPManager implements MessageDeliverySocket {
    private List<SocketClientHandler> clients;
    private final GameController gameController;
    private BlockingQueue<CommandRequest> commandQueue;
    //La coda messa a disposizione consente automaticamente di sincronizzare i thread in lettura/scrittura
    //Essa consente a due thread di prelevare dalla coda ed inserire nello stesso istante
    private int numPlayers;
    private Map<String, Function<JsonObject,MessageToClient>> commands;
    private volatile  boolean running;

    public TCPManager(GameController gameController) {
        this.gameController = gameController;
        clients = new ArrayList<>();
        commandQueue = new LinkedBlockingDeque<>();
        this.numPlayers = 5;
        this.commands = new HashMap<>();
        initCommands();
    }

    private void initCommands(){

        commands.put("create game", (params)-> {
                MessageToClient message = this.gameController.createGame(params.get("nickname").getAsString(), params.get("color").getAsString(),
                        params.get("numPlayers").getAsInt());
                this.numPlayers=params.get("numPlayers").getAsInt();
                return message;
        });
        //Il controller gestisce già la cattura delle eccezioni=> non le catturo perché avrò il messaggio giusto
        //in base al fatto che l' eccezione sia avventua o meno
        commands.put("join game", (params)->{
            MessageToClient message = this.gameController.joinGame(params.get("nickname").getAsString(),
                        params.get("totem").getAsString());
            return message;
        });
        /*commands.put("place totem", (params)->{
                this.gameController.placetotem(params.get("nickname").getAsString(),
                        params.get("index").getAsString());


         });*/
        /*commands.put("pick card", (params)->{

                this.gameController.pickCard(params.get("nickname").getAsString(),
                        params.get("cardID").getAsString());


        });*/
        /*commands.put("pick special", (params)->{

                this.gameController.pickSpecial(params.get("nickname").getAsString(),
                        params.get("cardID").getAsString());


        });*/
        /*commands.put("pick food", (params)->{

                return  this.gameController.pickFood(params.get("nickname").getAsString(),
            params.get("cardID").getAsString());


        });*/
        /*commands.put("end game", (params)->{

                return this.gameController.EndGame();


        });*/
    }
    public void enqueueCommandRequest(CommandRequest commandRequest){
        commandQueue.add(commandRequest);
    }
    public void startDispatcher(){
            Thread dispatcher = new Thread(() -> {
                while (running) {
                    try {
                        CommandRequest commandRequest = commandQueue.take();
                        Function<JsonObject,MessageToClient> command =  commands.get(commandRequest.getCommand());
                        MessageToClient response = command.apply(commandRequest.getParameters());
                        if(response!=null){
                            response.deliver(commandRequest.getSender(), TCPManager.this);
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();//Forzo a far tornare il flag a true, altrimenti non sarebbe possibile sapere se quel thread è ancora pronto
                        running = false;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            dispatcher.start();
    }


    public void registerHandler(SocketClientHandler socketClientHandler) {
        synchronized (clients) {
            clients.add(socketClientHandler);
        }
    }
    public void unregisterHandler(SocketClientHandler socketClientHandler) {
        synchronized (clients) {
            clients.remove(socketClientHandler);
        }
    }

    @Override
    public void sendTo(SocketClientHandler socketClientHandler, MessageToClient message) {
        if(socketClientHandler==null || message==null){
            throw new IllegalArgumentException("nickname not valid or message is null");
        }
        synchronized (clients){
            try{
                socketClientHandler.onMessage(message);
            }catch(Exception e){
                System.out.println("Unable to send message to clients");
            }

        }
    }

    @Override
    public void broadcast(MessageToClient message) {
        if(message==null){throw new NullPointerException("Message is null");}
        else{
            synchronized (clients) {
                for(SocketClientHandler socketClientHandler : clients){
                    try{
                        socketClientHandler.onMessage(message);
                    }catch(Exception e){
                        System.out.println("Unable to send message to clients");
                    }
                }
            }
        }
    }

    public void closeTCPConnection(){

    }
}
