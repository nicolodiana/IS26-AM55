package it.polimi.ingsw.am55.database;

import java.sql.SQLException;
import java.util.Map;

public interface DataAccessObject {
    void registerPlayer(String nickname,int point) throws SQLException;
    void registerGame(String gameID, int numPlayers) throws SQLException;
    Map<String,Integer> getGeneralClassification() throws SQLException;
    Map<String,Integer> getPlayerClassification()throws SQLException;
}
