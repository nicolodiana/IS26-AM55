package it.polimi.ingsw.am55.database;
import java.sql.*;
import java.util.Map;

public class DatabaseManger implements DataAccessObject{

    private Connection conn;

    public DatabaseManger() throws SQLException {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/nome_database","root","root");
    }


    @Override
    public void registerPlayer(String nickname, int point) {

    }

    @Override
    public void registerGame(String gameID, int numPlayers) throws SQLException {
        String query = "INSERT INTO Game VALUES ("+gameID+","+numPlayers+")";
        Statement stmt = conn.createStatement();
        stmt.executeQuery(query);
    }

    @Override
    public Map<String, Integer> getGeneralClassification() {
        return Map.of();
    }

    @Override
    public Map<String, Integer> getPlayerClassification() {
        return Map.of();
    }


}
