package it.polimi.ingsw.am55.message;

import it.polimi.ingsw.am55.ClientModel.ClientModel;

import java.util.List;

public class MultipleMessages extends MultipleMessagesStartGame {


    public MultipleMessages(List<MessageToClient> messages) {
        super(messages);
    }
    @Override
    public void update(ClientModel model) {
        for (MessageToClient message : messages) {
            message.update(model);
        }
    }
}
