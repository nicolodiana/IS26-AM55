package it.polimi.ingsw.am55.message;

import it.polimi.ingsw.am55.ClientModel.ClientModel;

import java.util.List;

public class MultipleMessagesStartGame extends MessageToClient {

    List<MessageToClient> messages;

    public MultipleMessagesStartGame(List<MessageToClient> messages) {
        this.messages = messages;
    }

    @Override
    public void update(ClientModel model) {
        messages.getFirst().update(model);
    }

    @Override
    public void deliver(String playerId, MessageDelivery context) {
        for(MessageToClient message : messages) {
            message.deliver(playerId, context);
        }
    }
}
