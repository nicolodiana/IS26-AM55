package it.polimi.ingsw.am55.message;

import it.polimi.ingsw.am55.ClientModel.ClientModel;
import it.polimi.ingsw.am55.dto.GameView;
/*
questa classe serve per riflettere un cambiamento di stato nella view, ma che comunque non
porta la necessità di ristampare la board
ad esempio il resolve evente senza eventi da effettivamente risolvere, devo comunicare
all client model che sono ripassato nello stato di placetotem del nuovo round , ma senza
necessità di stampare la board perche non ho tolto nessun evento sarebbe una replicazione
 */
public class SilentUpdateViewMessage implements MessageToClient {

    private final GameView gameView;
    private final String message;

    public SilentUpdateViewMessage(GameView gameView, String message) {
        this.gameView = gameView;
        this.message = message;
    }

    @Override
    public void update(ClientModel model) {
        model.clearError();
        model.setGameView(gameView);
        model.setStateRequest(message);
        model.setGameStarted(true);

        // Aggiorno la GameView nel model,
        // ma non voglio che la CLI ristampi la board.
        model.setLastMessageUpdatedGameView(false);
    }

    @Override
    public void deliver(String playerId, MessageDelivery context) {
        context.broadcast(this);
    }
}